CPSC 3740 Assignment 2
Jesse Huss
001209444

Questions are separated into different folders.
Q1, Q2, Q3, Q4

Within each folder is the parser, scanner, a Makefile and a pdf of the writeup for that question.
To test:

Within each folder run `make`

and then ./calc